﻿using common.config;
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace appengine
{
    public class Monitor
    {
        public static void Write(string message)
        {
            string dns = "localhost";
            int port = Settings.APPENGINE_MONITOR.PORT;

            IPAddress[] IPs = Dns.GetHostAddresses(dns);

            if (Settings.APPENGINE.IsListening(dns, port))
                try
                {
                    using (TcpClient tcp = new TcpClient(dns, port))
                    {
                        tcp.NoDelay = true;

                        NetworkStream stream = tcp.GetStream();
                        
                        byte[] response = Encoding.UTF8.GetBytes($"{Settings.APPENGINE_MONITOR.TOKEN}|{message}");

                        stream.Write(response, 0, response.Length);

                        tcp.Close();
                    }
                } catch (ObjectDisposedException) { return; }
            else
                return;
        }

        public static void Write(string type, string message)
        {
            string dns = "localhost";
            int port = Settings.APPENGINE_MONITOR.PORT;

            IPAddress[] IPs = Dns.GetHostAddresses(dns);

            if (Settings.APPENGINE.IsListening(dns, port))
                try
                {
                    using (TcpClient tcp = new TcpClient(dns, port))
                    {
                        tcp.NoDelay = true;

                        NetworkStream stream = tcp.GetStream();
                        
                        byte[] response = Encoding.UTF8.GetBytes($"{Settings.APPENGINE_MONITOR.TOKEN}|{type}|{message}");

                        stream.Write(response, 0, response.Length);

                        tcp.Close();
                    }
                } catch (ObjectDisposedException) { return; }
            else
                return;
        }
    }
}