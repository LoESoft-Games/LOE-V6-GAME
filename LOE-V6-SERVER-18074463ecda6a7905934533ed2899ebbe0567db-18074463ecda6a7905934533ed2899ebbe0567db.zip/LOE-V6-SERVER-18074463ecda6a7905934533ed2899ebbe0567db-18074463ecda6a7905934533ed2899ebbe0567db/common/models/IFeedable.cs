﻿public interface IFeedable
{
    ushort FeedPower { get; set; }
}