﻿namespace common.config
{
    public enum AccountType:int
    {
        FREE_ACCOUNT = 0,
        VIP_ACCOUNT = 1,
        LEGENDARY_ACCOUNT = 2,
        LOESOFT_ACCOUNT = 3,
        ULTIMATE_ACCOUNT = 4
    }
}