#region

using System;

#endregion

namespace common.graphics { }