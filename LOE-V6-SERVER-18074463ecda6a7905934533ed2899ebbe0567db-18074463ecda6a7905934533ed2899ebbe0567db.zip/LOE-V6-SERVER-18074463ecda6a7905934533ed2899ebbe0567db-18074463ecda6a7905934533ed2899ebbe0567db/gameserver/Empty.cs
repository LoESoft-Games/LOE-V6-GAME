﻿namespace gameserver
{
    internal static class Empty<T>
    {
        public static T[] Array = new T[0];
    }
}