﻿namespace gameserver.networking
{
    internal partial class NetworkHandler
    {
        private class OutgoingToken
        {
            public Message Packet;
        }
    }
}