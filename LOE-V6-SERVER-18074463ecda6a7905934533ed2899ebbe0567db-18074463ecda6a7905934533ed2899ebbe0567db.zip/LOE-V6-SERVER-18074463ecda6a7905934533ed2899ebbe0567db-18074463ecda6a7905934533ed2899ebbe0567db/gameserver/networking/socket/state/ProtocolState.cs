﻿namespace gameserver.networking
{
    public enum ProtocolState
    {
        Connected,
        Handshaked,
        Ready,
        Disconnected
    }
}